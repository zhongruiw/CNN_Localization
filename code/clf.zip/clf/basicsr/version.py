# GENERATED VERSION FILE
# TIME: Mon Apr 18 21:35:20 2022
__version__ = '1.2.0+386ca20'
short_version = '1.2.0'
version_info = (1, 2, 0)
