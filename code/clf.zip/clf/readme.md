This implementation is modified from [NAFNet]([GitHub - zhongruiw/NAFNet](https://github.com/zhongruiw/NAFNet)) based on [BasicSR](https://github.com/xinntao/BasicSR) which is an open source toolbox for image/video restoration tasks.

Tutorials of this implementation framework please see:  [NAFNet]([GitHub - zhongruiw/NAFNet](https://github.com/zhongruiw/NAFNet)).

A quick command for launching training on PyTorch:

python -m torch.distributed.launch --nproc_per_node=4 --master_port=4321 basicsr/train.py -opt options/train/SRCNN-F16-sob-64-enkf-xtloss.yml --launcher pytorch
